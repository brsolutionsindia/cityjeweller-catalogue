// /app/catalog/labgrown/page.tsx
import CatalogView from '../CatalogView';

export default function LabGrownPage() {
  return <CatalogView category="labgrown" />;
}