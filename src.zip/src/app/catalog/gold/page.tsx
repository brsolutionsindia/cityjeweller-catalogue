// /app/catalog/gold/page.tsx
import CatalogView from '../CatalogView';

export default function GoldPage() {
  return <CatalogView category="gold" />;
}
