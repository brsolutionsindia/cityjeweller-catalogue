// /app/catalog/misc/page.tsx
import CatalogView from '../CatalogView';

export default function MiscPage() {
  return <CatalogView category="misc" />;
}
