// /src/app/catalog/silver/page.tsx
import SilverCatalog from './SilverCatalog';

export default function SilverCatalogPage() {
  return <SilverCatalog />;
}
