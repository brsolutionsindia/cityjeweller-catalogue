// /app/catalog/diamond/page.tsx
import CatalogView from '../CatalogView';

export default function DiamondPage() {
  return <CatalogView category="diamond" />;
}
