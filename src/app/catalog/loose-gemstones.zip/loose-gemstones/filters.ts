export const gemstoneTypes = [
  { label: "Moonga", image: "/gemstone-moonga.png", type: "LG-Moonga" },
  { label: "Emerald", image: "/gemstone-emerald.png", type: "LG-Emerald" },
  { label: "Blue Sapphire", image: "/gemstone-blue.png", type: "LG-Neelam" },
  { label: "Yellow Sapphire", image: "/gemstone-yellow.png", type: "LG-Pukhraj" },
  { label: "OPAL", image: "/gemstone-opal.png", type: "LG-Opal" },
];
